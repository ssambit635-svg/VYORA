# Vyora UI Design Pack

This package contains the finalized UI direction for the Vyora SAR-image colourization hackathon project.

## Contents

- `VYORA_UI_DESIGN_BRIEF.md` — complete visual direction, layouts, component guidance, design rules, and an implementation prompt.
- `design-tokens.json` — colours, typography, spacing, and motion tokens.
- `assets/vyora-globe-dashboard.png` — selected original Vyora dashboard concept.
- `references/opsmind-style-reference.png` — user-provided visual inspiration reference.

## Important instruction

Use the reference for visual inspiration only. Build original Vyora components and copy; do not reproduce external branding, wording, or exact layouts.
