# Vyora UI Design Brief

**Purpose:** Final visual direction for the Vyora hackathon web application.  
**Project:** Vyora — confidence-aware SAR image colour interpretation.  
**Reference asset:** `assets/vyora-globe-dashboard.png`

---

## 1. Design direction

Build Vyora as a **quiet, premium Earth-intelligence dashboard**.

It should feel like a real satellite-analysis product: dark, precise, spacious, and refined. The reference image's restrained black dashboard, rounded charcoal cards, large central globe, and balanced information density are the correct visual direction.

### Core visual statement
> Vyora is a serious geospatial intelligence tool, not a generic chatbot, neon cyberpunk app, or flashy AI-image generator.

---

## 2. What to keep from the selected reference image

- Near-black background with subtle navy/charcoal surfaces.
- Large central globe/data visual used as a dashboard hero.
- Matte, rounded information cards with thin low-contrast borders.
- Generous spacing and a clean visual hierarchy.
- Small circular utility buttons and one clear selected navigation pill.
- Soft lavender/purple used only as a restrained accent.
- Data-dense layout that still feels calm and readable.

### Globe usage
The globe is a **dashboard/home visual**, not the core SAR analysis result. It should be a detailed point-cloud or wireframe Earth visual in subdued lavender, with minimal animation if any.

Use it to communicate global/geospatial intelligence. Do not show a fake live global dataset, a fake satellite stream, or a world map claiming real activity.

---

## 3. Explicit style rules: avoid AI slop

Do **not** use:

- neon purple glow around every panel;
- holographic beams, laser scans, magenta smoke, or particle explosions;
- excessive gradients or glass blur;
- generic “Ask AI anything” chat UI;
- fake charts, fake live metrics, fake user counts, or fake global alerts;
- visual clutter, too many graphs, or a cyber-security style matrix interface;
- glowing world maps unrelated to the SAR workflow;
- a copied version of the reference product's branding or wording.

The UI may use a subtle purple accent and a low-opacity Earth horizon/grid treatment, but the experience must remain matte, minimal, and product-like.

---

## 4. Visual system

### Colour tokens

| Use | Hex | Notes |
|---|---:|---|
| App background | `#05060A` | Almost black, slightly cool |
| Primary panel | `#0D1018` | Main card background |
| Raised panel | `#141824` | Nested cards / hover states |
| Border | `#272D3C` | Thin, low-contrast outline |
| Primary text | `#F4F6FA` | High readability |
| Secondary text | `#8E98A9` | Labels and metadata |
| Violet accent | `#A78BFA` | Use sparingly for selected/AI states |
| Cyan accent | `#4CD8FF` | Utility/neutral status, not everywhere |
| Success | `#48C78E` | Valid model/data state |
| Warning | `#E8B45B` | Requires attention |
| Error / low confidence | `#E56D73` | Use only for clear errors/low confidence |

### Geographic semantic colours
These are reserved for the actual SAR interpretation image and legends.

| Land feature | Suggested colour |
|---|---:|
| Water | `#42BCE8` |
| Vegetation | `#71D66A` |
| Built-up area | `#FFB66E` |
| Bare land / other | `#D9BD83` |
| Low-confidence overlay | `#E56D73` with opacity |

**Rule:** Violet is a UI/model accent. Do not use violet as a geographic land-class colour.

### Typography

- Headings: `Space Grotesk`, `Sora`, or a similar geometric sans-serif.
- Body/UI text: `Inter`, `Manrope`, or system sans-serif.
- Technical values/metadata: `JetBrains Mono` or a system monospace font.

Use strong typography hierarchy. Do not use thin, low-contrast text for important information.

---

## 5. Primary dashboard: Vyora Overview

### Layout

```text
┌──────────────────────────────────────────────────────────────────────────┐
│ VYORA       [ Overview ] [ Analyse ] [ Scenes ] [ Method ]      icons    │
├─────────────────┬────────────────────────────┬───────────────────────────┤
│ SAR Scene       │                            │ Interpretation            │
│ Library         │    Point-cloud Earth       │ Confidence                │
│                 │    / spatial hero visual   │ and model state           │
│ - Coastal       │                            │                           │
│ - Urban         │                            │ Feature categories        │
│ - Vegetation    │                            │                           │
├─────────────────┴────────────────────────────┴───────────────────────────┤
│ Recent scenes       Structure preservation       Inference time            │
└──────────────────────────────────────────────────────────────────────────┘
```

### Header

- Left: `VYORA` wordmark and a minimal circular mark.
- Centre: pill-style navigation; only the active page has a light/bright pill.
- Right: search/notification/profile controls only if they work. Otherwise keep this side minimal.

### Left cards

- **SAR Scene Library:** 3–4 actual curated demo scenes.
- **Model Status:** show only factual state, for example `Model loaded` or `Demo mode`.
- Keep compact; do not overcrowd.

### Centre hero

- A restrained point-cloud/wireframe Earth globe.
- Subtle lavender data texture, no bloom or neon aura.
- Supporting copy example:

```text
Vyora Overview
Confidence-aware SAR interpretation.
```

### Right card

- **Interpretation Confidence** card.
- For a live analysis, show actual model confidence.
- On a dashboard with no selected scene, show a neutral state such as `Select a scene to view confidence`.
- Do not fill the dashboard with fake percentage values.

### Lower cards

These cards are useful only when backed by actual data:

- Recent analysed scenes
- Structure preservation (evaluation metric)
- Median inference time
- Dataset/model readiness

If a number is not yet measured, show `Not evaluated yet` rather than inventing it.

---

## 6. Analysis workspace: the core product screen

The actual SAR colourization workflow should use a more functional layout than the overview dashboard.

```text
┌───────────────┬───────────────────────────────────────┬───────────────────┐
│ Scene library │      RAW SAR  |  VYORA OUTPUT          │ AI interpretation │
│ Upload image  │     large before/after comparison      │ Confidence        │
│ Scene details │     canvas is the visual priority      │ Feature estimates │
│               │                                       │ Model metadata    │
└───────────────┴───────────────────────────────────────┴───────────────────┘
```

### Core interaction

The main wow interaction is a **before/after vertical comparison slider**:

- Left: raw grayscale SAR image.
- Right: Vyora’s AI-estimated colour geographic interpretation.
- Slider handle: thin, simple, and touch-friendly.
- A label should always state: `AI-estimated geographic interpretation`.

### Right-side insight panel

Show only useful information:

- confidence summary;
- water / vegetation / built-up / bare-other estimated feature values;
- model version;
- inference time;
- a short limitation notice.

Avoid a wall of charts.

### Confidence mode

Use tabs or compact toggles:

```text
[ Interpretation ] [ Confidence ] [ Structure ]
```

The confidence overlay should be legible and include a text legend. Low confidence means model uncertainty, not a confirmed real-world hazard.

---

## 7. Motion and micro-interactions

Motion must be quiet and purposeful.

### Allowed

- 150–250 ms card hover/focus transitions.
- Slow, nearly static drift/rotation on the dashboard globe.
- A single scanning line over an image while real inference is in progress.
- Smooth reveal of confidence layer and comparison slider.

### Not allowed

- continuously pulsing neon panels;
- spark/particle storms;
- long fake loading sequences;
- flashy motion that makes the app look like a video-game HUD.

---

## 8. Mobile requirements

Do not force the three-column desktop dashboard onto a phone.

Mobile analysis order:

1. Top bar with Vyora logo.
2. Full-width SAR comparison canvas.
3. `Interpretation / Confidence / Structure` toggle.
4. Confidence card and feature cards.
5. Collapsible scene metadata.
6. Download/export control.

Use at least 44 px touch targets and keep the image comparison canvas as the largest element.

---

## 9. Build instructions for an implementation agent

Use this statement when building the UI:

> Create Vyora as a restrained black Earth-intelligence dashboard. Follow the selected dashboard reference for spacing, rounded charcoal cards, clean navigation, and a subdued lavender point-cloud globe. The analysis workspace must prioritise a raw-SAR versus colour-interpretation comparison slider. Use purple only as a small model/UI accent, retain meaningful geographic colours in results, and avoid neon glow, holograms, fake metrics, chatbot layouts, and generic AI visual effects.

---

## 10. Asset usage

- `assets/vyora-globe-dashboard.png` is the chosen visual direction mockup.
- `references/opsmind-style-reference.png` is the user-provided style reference.
- Use them as visual inspiration only. Do not reproduce external branding, labels, or exact product UI.
